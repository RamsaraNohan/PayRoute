import { HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { auth, db } from "../services/firebaseAdmin";

export async function signalDrop(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return { status: 401, jsonBody: { error: 'Unauthorized' } };
    }

    try {
        const idToken = authHeader.split('Bearer ')[1];
        await auth.verifyIdToken(idToken); // Passenger authorization check

        const body = await request.json() as any;
        const { tripId } = body;

        await db.runTransaction(async (t) => {
            const tripRef = db.collection('trips').doc(tripId);
            const tripSnap = await t.get(tripRef);
            
            if (!tripSnap.exists) {
                throw new Error('Trip not found');
            }
            
            const tripData = tripSnap.data() as any;
            if (tripData.status !== 'ONGOING') {
                throw new Error('Trip already completed');
            }

            // Deduct fare logic here (omitted for mock)
            // Example:
            // const cost = 4500;
            // update Passenger Wallet logic

            t.update(tripRef, { 
                status: 'COMPLETED', 
                dropTime: new Date().toISOString() 
            });

            const tokenRef = db.collection('tokens').doc(tripData.tokenId);
            t.update(tokenRef, { status: 'COMPLETED' });
        });

        return { status: 200, jsonBody: { success: true } };
    } catch (error: any) {
        context.error(error);
        return { status: 400, jsonBody: { error: error.message || 'Internal server error' } };
    }
}
